package BookProject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class Registration {
public void registrationPage() throws SQLException {
        // TODO Auto-generated method stub
         DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
            String oracleUrl = "jdbc:oracle:thin:@localhost:1521/xe";
            Connection con = DriverManager.getConnection(oracleUrl, "Parikshit","parikshitid2");
            Statement stmt= con.createStatement();
            Scanner sc= new Scanner(System.in);
//Registration page
//user can register with the valid details.
            System.out.println("Welcome To Registration Page");
            System.out.println("Enter the Username");
            while (!sc.hasNext("[A-Za-z]+")) {
                System.out.println("Please enter valid Username!");
                sc.next();
            }
            String Username=sc.next();
            System.out.println("Enter the Password");
            String Password=sc.next();;
            System.out.println("Enter the Address");
            String Address=sc.next();          
            System.out.println("Enter the Pin_code");
            int Pin_code=sc.nextInt();
            ResultSet rs=stmt.executeQuery("insert into Registration values('"+Username+"','"+Password+"','"+Address+"','"+Pin_code+"')");
            System.out.println("Registered successfully");
}    
}