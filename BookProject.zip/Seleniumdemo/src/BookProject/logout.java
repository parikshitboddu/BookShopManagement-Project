package BookProject;

 

import java.util.Scanner;

 

public class logout extends PaymentModule {
    public void Logout() {
    	

     //Logout functionality

     // public static void main(String[] args) {

            System.out.println("Are you sure you want to log out? (Yes/No) ");


            Scanner input = new Scanner(System.in);
            String confirm = input.nextLine();


            if (confirm.equalsIgnoreCase("Yes")) {
              System.out.println("You have been logged out.");
            }
            else {
                System.out.println("logout failed!");
            }
          }
        }