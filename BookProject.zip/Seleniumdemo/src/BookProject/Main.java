package BookProject;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.Scanner;
public class Main extends Registration {
    public static void main(String[] args) throws SQLException, ClassNotFoundException, ParseException {
//Main page of the application.
//Code should be executed by this page.
        System.out.println("Welcome To Book Shop Management System");
        logout v=new logout();
        System.out.println("1.Registration");
        System.out.println("2.Login");
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Number");
        int number=sc.nextInt();
//Included switch condition to check respective modules
        switch(number) {
        case 1:
            v.registrationPage();
            v.Login();
            break;
        case 2:
            v.Login();
            break;
        }
        v.Search();
        v.AddToCart();
        v.Payment();
        System.out.println("Thank You for Ordering");
        v.Logout();
        }}