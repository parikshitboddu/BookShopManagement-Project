package BookProject;
import java.sql.*;
import java.util.Scanner;
public class LoginModule extends Registration{
    public void Login() throws SQLException{
//Included driver connection.
//Entered values will compare with the valid data stored in the database. 
    Driver d= new oracle.jdbc.driver.OracleDriver();
    DriverManager.registerDriver(d);        
    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Parikshit","parikshitid2");
    Statement stmt=con.createStatement();
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter the UserName");
    String UserName=sc.next();
    System.out.println("Enter the Password");
    String Password=sc.next();
    ResultSet rs=stmt.executeQuery("select * from Registration where username='"+UserName+"' and password='"+Password+"'");
    if(rs.next()) {
         System.out.println("Login Sccessfully");
        }
        else {
        System.out.println("login fail");
        Login();
        }
}}