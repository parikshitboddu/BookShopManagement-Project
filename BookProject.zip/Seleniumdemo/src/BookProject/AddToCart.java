package BookProject;
import java.util.Scanner;
   public class AddToCart extends SearchModule
    {  
	   //Adding the books to cart.
       public void AddToCart(){
        //public static void main(String[]args)
        {
        Scanner sc=new Scanner(System.in);
        System.out.println("1.Failure             Rs-500/-");
        System.out.println("2.Physics             Rs-300/-");
        System.out.println("3.success             Rs-400/-");
        System.out.println("4.MindSet             Rs-600/-");
        System.out.println("5.Stay Cliam          Rs-100/-");
        System.out.println("6.Java                Rs-400/-");
        System.out.println("7.Girls MindSet       Rs-500/-");
        System.out.println("8.Money Making        Rs-700/-");
        System.out.println("9.Business            Rs-200/-");
        System.out.println("10.Game books         Rs-300/-");
        System.out.println("11. psychoKiller      Rs-300/-");
        System.out.println("Enter the Book Number");
        int BookNumber=sc.nextInt();
        //The user have to enter the number which is assigned to respective book.
        //If user enter another number which is not mentioned in the cart module, it should show pop-up message.
         if(BookNumber <11) {
        switch(BookNumber) {
        case 1:
            System.out.println("Book Name is Failure");
            System.out.println("Price    RS-500/-");
            break;
        case 2:
            System.out.println("Book Name is Physics");
            System.out.println("Price    RS-300/-");
            break;
        case 3:
            System.out.println("Book Name is success");
            System.out.println("Price    RS-400/-");
            break;
        case 4:
            System.out.println("Book Name is MindSet");
            System.out.println("Price    RS-600/-");
            break;
        case 5:
            System.out.println("Book Name is Stay Cliam");
            System.out.println("Price    RS-100/-");
            break;
        case 6:
            System.out.println("Book Name is Java");
            System.out.println("Price    RS400/-");
            break;
        case 7:
            System.out.println("Book Name is Girls MindSet");
            System.out.println("Price    RS-500/-");
            break;
        case 8:
            System.out.println("Book Name is Money Making");
            System.out.println("Price    RS-700/-");
            break;
        case 9:
            System.out.println("Book Name is Business");
            System.out.println("Price    RS-200/-");
            break;
        case 10:
            System.out.println("Book Name is Game books");
            System.out.println("Price    RS-300/-");
            break;
        case 11:
            System.out.println("Book Name is psychoKiller");
            System.out.println("Price    RS-300/-");

 

            }
        System.out.println("Enter the Quantity");
        long Quantity=sc.nextLong();
        System.out.println("Added  To Cart");
        }
        else {
             System.out.println("Book is not Available");    
         }}}}