package BookProject;
import java.util.Date;
import java.util.Scanner;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
public class PaymentModule extends AddToCart{
    public void Payment() throws ClassNotFoundException, SQLException, ParseException {

 


        // TODO Auto-generated method stub

 

        Class.forName("oracle.jdbc.driver.OracleDriver"); 
        //DriverManager.registerDriver(d);
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Parikshit","parikshitid2");
        Statement stmt=con.createStatement();
        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome to payment Details");
        System.out.println("Enter the Credit/Debit Card NUmber");
        long cardNumber = sc.nextLong();
        System.out.println("Enter a date (mm/dd/yyyy): ");
        String input = sc.next();
//Date format should tally with the given format.
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        Date validDate = sdf.parse(input);
        System.out.println("Enter the Card Holder Name");
        while (!sc.hasNext("[A-Za-z]+")) {
            System.out.println("Please enter valid Card Holder Name!");
            sc.next();
        }
        String CardHolderName = sc.next();
        System.out.println("Enter the Total Amount");
        int TotalAmount = sc.nextInt();

 

      
        System.out.println("Payment successfully completed");
    }
}