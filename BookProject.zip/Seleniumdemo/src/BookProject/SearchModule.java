package BookProject;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

//Search Module
//User can search for respective book which is available in the database.

public class SearchModule extends LoginModule {
    public void Search() throws SQLException {
    Driver d= new oracle.jdbc.driver.OracleDriver();
      DriverManager.registerDriver(d);
      Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "Parikshit","parikshitid2");
      Statement stmt=con.createStatement();
      Scanner sc=new Scanner(System.in);
      System.out.println("Entre the Book Name");
      String BookName=sc.next();
      ResultSet rs=stmt.executeQuery("select * from searchModule where BookName='"+BookName+"'");
      if (rs.next()) {
          System.out.println("Available " + BookName);
      } else {
          System.out.println(" Not Available");
          if (!sc.hasNext("[Not Available]")) {
              System.out.println("please enter valid book name!");
          sc.next();
              rs = stmt.executeQuery("select * from searchModule where BookName='" + BookName + "'");
              if (rs.next()) {
                  System.out.println("Available " + BookName);
              }
              sc.next();
          }
      }
    }

    }